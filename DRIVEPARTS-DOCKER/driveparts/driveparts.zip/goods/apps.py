from django.apps import AppConfig


class GoodsConfig(AppConfig):
    verbose_name = 'Авто товары'
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'goods'
